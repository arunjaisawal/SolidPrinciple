﻿using OpenClosedP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidPrinciple.Client

{

    //Interface segeregation principle
    class Program
    {
        public bool FaxContent(string content)
        {
            Console.WriteLine("Fax Done ");
            return true;
        }

        public bool PhotoCopyContent(string content)
        {
            Console.WriteLine("Photo Copy Done ");
            return true;
        }

        public bool PrintContent(string content)
        {
            Console.WriteLine("Print Done ");
            return true;
        }

        public bool PrintDuplexContent(string content)
        {
            Console.WriteLine("Print Duplex Done ");
            return true;
        }

        public bool ScanContent(string content)
        {
            Console.WriteLine("Scan Done ");
            return true;
        }


        static void Main(string[] args)
        {
            Employee objJhon =new  PermanentEmployee(1, "Jhon");
            Employee objJason =new TemporaryEmployee(2, "Jason");
            Console.WriteLine(string.Format("Emplyee {0} Bonus:{1}", objJhon.ToString(),
                objJhon.CalculateBonus(100000).ToString()));

            Console.WriteLine(string.Format("Emplyee {0} Bonus:{1}", objJason.ToString(),
               objJason.CalculateBonus(150000).ToString()));
            Console.ReadLine();
        }
    }
}
